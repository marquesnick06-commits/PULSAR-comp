(()=>{"use strict";
const canvas=document.querySelector("#game"),ctx=canvas.getContext("2d");
const $=id=>document.getElementById(id);
let W=0,H=0,dpr=1,state="menu",last=0,time=0,score=0,wave=1,lives=3,spawn=0,fire=0,shield=0,muted=false;
let player,bullets=[],enemies=[],enemyShots=[],particles=[],orbs=[],stars=[],keys=new Set(),pointer=null,joy=null,raf=0;
const bestKey="pulsar-offline-best-v1";
function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=Math.floor(W*dpr);canvas.height=Math.floor(H*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);stars=Array.from({length:Math.floor(W*H/5500)},()=>({x:Math.random()*W,y:Math.random()*H,z:.2+Math.random()*.8}));}
addEventListener("resize",resize);resize();
function best(){try{return +(localStorage.getItem(bestKey)||0)}catch{return 0}}
$("best").textContent=String(best()).padStart(6,"0");
function show(id){for(const s of document.querySelectorAll(".screen"))s.hidden=s.id!==id}
function start(){state="playing";score=0;wave=1;lives=3;spawn=0;fire=0;shield=0;bullets=[];enemies=[];enemyShots=[];particles=[];orbs=[];player={x:W/2,y:H*.72,vx:0,vy:0,angle:-Math.PI/2,inv:2};$("hud").hidden=false;$("touchControls").hidden=false;show("");$("score").textContent="000000";$("wave").textContent="01";$("lives").textContent="♥ ♥ ♥";$("toast").textContent="SOBREVIVA ÀS ONDAS";setTimeout(()=>{if(state==="playing")$("toast").textContent=""},1800);last=performance.now();cancelAnimationFrame(raf);raf=requestAnimationFrame(loop)}
function menu(){state="menu";$("hud").hidden=true;$("touchControls").hidden=true;show("menu");$("best").textContent=String(best()).padStart(6,"0")}
function pause(){if(state!=="playing")return;state="paused";show("pause");$("touchControls").hidden=true}
function resume(){if(state!=="paused")return;state="playing";show("");$("touchControls").hidden=false;last=performance.now();raf=requestAnimationFrame(loop)}
function over(){state="over";$("hud").hidden=true;$("touchControls").hidden=true;if(score>best()){try{localStorage.setItem(bestKey,String(score))}catch{}}$("finalScore").textContent=score;$("finalWave").textContent=wave;show("over")}
$("startBtn").onclick=start;$("againBtn").onclick=start;$("howBtn").onclick=()=>show("how");$("backBtn").onclick=()=>show("menu");$("pauseBtn").onclick=pause;$("resumeBtn").onclick=resume;$("quitBtn").onclick=menu;$("menuBtn").onclick=menu;
function shoot(){if(fire>0)return;fire=.18;bullets.push({x:player.x+Math.cos(player.angle)*19,y:player.y+Math.sin(player.angle)*19,vx:Math.cos(player.angle)*530,vy:Math.sin(player.angle)*530,life:1.1});if(!muted)tone(680,.035)}
function tone(freq,dur){try{const c=tone.c||(tone.c=new(window.AudioContext||window.webkitAudioContext)()),o=c.createOscillator(),g=c.createGain();o.frequency.value=freq;o.type="square";g.gain.value=.025;o.connect(g);g.connect(c.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,c.currentTime+dur);o.stop(c.currentTime+dur)}catch{}}
function burst(x,y,color,n=12){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,s=35+Math.random()*190;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.25+Math.random()*.55,max:.8,color,size:1+Math.random()*3})}}
function spawnEnemy(){const type=Math.random()<.7?"scout":"hunter",edge=Math.floor(Math.random()*4);let x=edge===0?0:edge===1?W:Math.random()*W,y=edge===2?0:edge===3?H*.4:-10;enemies.push({x,y,hp:type==="hunter"?3:1,max:type==="hunter"?3:1,type,r: type==="hunter"?18:12,spd:(type==="hunter"?50:75)+wave*4,phase:Math.random()*6.28,shot:1+Math.random()*2})}
function loop(now){if(state!=="playing")return;const dt=Math.min((now-last)/1000,.033);last=now;time+=dt;update(dt);draw();raf=requestAnimationFrame(loop)}
function update(dt){if(!player)return;
let dx=0,dy=0;if(keys.has("ArrowLeft")||keys.has("KeyA"))dx--;if(keys.has("ArrowRight")||keys.has("KeyD"))dx++;if(keys.has("ArrowUp")||keys.has("KeyW"))dy--;if(keys.has("ArrowDown")||keys.has("KeyS"))dy++;
if(joy){dx=joy.x;dy=joy.y}const len=Math.hypot(dx,dy);if(len>1){dx/=len;dy/=len}
player.vx+=(dx*260-player.vx)*Math.min(1,dt*6);player.vy+=(dy*260-player.vy)*Math.min(1,dt*6);player.x=Math.max(18,Math.min(W-18,player.x+player.vx*dt));player.y=Math.max(55,Math.min(H-20,player.y+player.vy*dt));
if(pointer&&pointer.active){const a=Math.atan2(pointer.y-player.y,pointer.x-player.x);player.angle=a;if(pointer.fire)shoot()}else if(keys.has("Space"))shoot();
fire=Math.max(0,fire-dt);shield=Math.max(0,shield-dt);player.inv=Math.max(0,player.inv-dt);spawn-=dt;if(spawn<=0){spawn=Math.max(.22,1.05-wave*.055);spawnEnemy()}
for(const b of bullets){b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt}bullets=bullets.filter(b=>b.life>0&&b.x>-20&&b.x<W+20&&b.y>-20&&b.y<H+20);
for(const e of enemies){const a=Math.atan2(player.y-e.y,player.x-e.x);e.phase+=dt*2.3;e.x+=Math.cos(a)*e.spd*dt+Math.sin(e.phase)*22*dt;e.y+=Math.sin(a)*e.spd*dt+Math.cos(e.phase)*10*dt;e.shot-=dt;if(e.type==="hunter"&&e.shot<=0){e.shot=2.1;enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*145,vy:Math.sin(a)*145,r:4,life:4})}}
for(const b of bullets){for(const e of enemies){if(e.hp<=0)continue;if(Math.hypot(b.x-e.x,b.y-e.y)<e.r+4){e.hp--;b.life=0;burst(b.x,b.y,"#56f4e8",3);if(e.hp<=0){score+=e.type==="hunter"?35:10;burst(e.x,e.y,e.type==="hunter"?"#ffbe5c":"#56f4e8",18);if(Math.random()<.12)orbs.push({x:e.x,y:e.y,r:8,life:8});}}}}
enemies=enemies.filter(e=>{if(e.hp<=0)return false;if(Math.hypot(player.x-e.x,player.y-e.y)<e.r+12){hit();e.hp=0;return false}return e.y<H+40&&e.x>-50&&e.x<W+50});
for(const b of enemyShots){b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;if(Math.hypot(b.x-player.x,b.y-player.y)<16){b.life=0;hit()}}enemyShots=enemyShots.filter(b=>b.life>0&&b.x>-20&&b.x<W+20&&b.y>-20&&b.y<H+20);
for(const o of orbs){o.life-=dt;if(Math.hypot(o.x-player.x,o.y-player.y)<24){o.life=0;shield=5;score+=20;burst(o.x,o.y,"#ffbe5c",14)}}orbs=orbs.filter(o=>o.life>0);
for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.98;p.vy*=.98;p.life-=dt}particles=particles.filter(p=>p.life>0);
wave=Math.floor(score/180)+1;$("score").textContent=String(score).padStart(6,"0");$("wave").textContent=String(wave).padStart(2,"0");$("lives").textContent="♥ ".repeat(Math.max(0,lives)).trim();
}
function hit(){if(player.inv>0)return;if(shield>0){shield=0;burst(player.x,player.y,"#56f4e8",15);return}lives--;player.inv=1.5;burst(player.x,player.y,"#ff667e",20);if(lives<=0)over()}
function draw(){ctx.clearRect(0,0,W,H);ctx.fillStyle="#071018";ctx.fillRect(0,0,W,H);
for(const s of stars){ctx.globalAlpha=.25+s.z*.65;ctx.fillStyle=s.z>.8?"#56f4e8":"#b4d4e5";ctx.fillRect(s.x,(s.y+time*18*s.z)%H,1.2*s.z,1.2*s.z)}ctx.globalAlpha=1;
ctx.save();ctx.strokeStyle="#56f4e80c";ctx.lineWidth=1;for(let x=0;x<W;x+=50){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=0;y<H;y+=50){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}ctx.restore();
for(const b of bullets){ctx.fillStyle="#b9fffb";ctx.shadowBlur=12;ctx.shadowColor="#56f4e8";ctx.beginPath();ctx.arc(b.x,b.y,3,0,7);ctx.fill()}ctx.shadowBlur=0;
for(const b of enemyShots){ctx.fillStyle="#ff667e";ctx.shadowBlur=10;ctx.shadowColor="#ff667e";ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,7);ctx.fill()}ctx.shadowBlur=0;
for(const e of enemies){ctx.save();ctx.translate(e.x,e.y);ctx.rotate(time*(e.type==="hunter"?-.7:1));ctx.strokeStyle=e.type==="hunter"?"#ffbe5c":"#ff667e";ctx.fillStyle="#172832";ctx.lineWidth=2;ctx.shadowBlur=14;ctx.shadowColor=ctx.strokeStyle;ctx.beginPath();for(let i=0;i<6;i++){let a=i*Math.PI/3;const r=e.r*(i%2?.78:1);ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r)}ctx.closePath();ctx.fill();ctx.stroke();ctx.shadowBlur=0;ctx.restore()}
for(const o of orbs){ctx.strokeStyle="#ffbe5c";ctx.shadowBlur=16;ctx.shadowColor="#ffbe5c";ctx.lineWidth=2;ctx.beginPath();ctx.arc(o.x,o.y,o.r*(1+Math.sin(time*5)*.15),0,7);ctx.stroke();ctx.shadowBlur=0}
for(const p of particles){ctx.globalAlpha=Math.max(0,p.life/p.max);ctx.fillStyle=p.color;ctx.fillRect(p.x,p.y,p.size,p.size)}ctx.globalAlpha=1;
if(player&&state==="playing"){ctx.save();ctx.translate(player.x,player.y);ctx.rotate(player.angle);ctx.globalAlpha=player.inv>0&&Math.sin(time*30)>0?.3:1;ctx.shadowBlur=18;ctx.shadowColor="#56f4e8";ctx.fillStyle="#56f4e8";ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-13,-11);ctx.lineTo(-7,0);ctx.lineTo(-13,11);ctx.closePath();ctx.fill();ctx.fillStyle="#ffbe5c";ctx.beginPath();ctx.moveTo(-8,-5);ctx.lineTo(-17,0);ctx.lineTo(-8,5);ctx.fill();ctx.restore();ctx.shadowBlur=0;if(shield>0){ctx.strokeStyle="#56f4e8";ctx.globalAlpha=.45+Math.sin(time*7)*.25;ctx.beginPath();ctx.arc(player.x,player.y,27,0,7);ctx.stroke();ctx.globalAlpha=1}}
}
let joyStart=null;const joyEl=$("joystick"),stick=$("stick");
joyEl.addEventListener("pointerdown",e=>{joyStart={x:e.clientX,y:e.clientY,id:e.pointerId};joyEl.setPointerCapture(e.pointerId);});
joyEl.addEventListener("pointermove",e=>{if(!joyStart||joyStart.id!==e.pointerId)return;let x=e.clientX-joyStart.x,y=e.clientY-joyStart.y,l=Math.hypot(x,y),m=32;if(l>m){x*=m/l;y*=m/l}joy={x:x/m,y:y/m};stick.style.transform=`translate(${x}px,${y}px)`});
function joyEnd(){joy=null;joyStart=null;stick.style.transform=""}joyEl.addEventListener("pointerup",joyEnd);joyEl.addEventListener("pointercancel",joyEnd);
$("fireBtn").addEventListener("pointerdown",e=>{e.preventDefault();pointer={x:player?.x+Math.cos(player?.angle||0)*100,y:player?.y+Math.sin(player?.angle||0)*100,fire:true,active:true};shoot()});$("fireBtn").addEventListener("pointerup",()=>{if(pointer)pointer.fire=false});$("fireBtn").addEventListener("pointercancel",()=>{if(pointer)pointer.fire=false});
canvas.addEventListener("pointerdown",e=>{if(state!=="playing"||e.target.closest("button"))return;pointer={x:e.clientX,y:e.clientY,fire:true,active:true};canvas.setPointerCapture(e.pointerId);shoot()});
canvas.addEventListener("pointermove",e=>{if(pointer&&pointer.active){pointer.x=e.clientX;pointer.y=e.clientY}});
canvas.addEventListener("pointerup",()=>{if(pointer)pointer.fire=false});canvas.addEventListener("pointercancel",()=>{pointer=null});
addEventListener("keydown",e=>{keys.add(e.code);if(e.code==="KeyP"){state==="playing"?pause():resume()}if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code))e.preventDefault()});addEventListener("keyup",e=>keys.delete(e.code));
document.addEventListener("visibilitychange",()=>{if(document.hidden&&state==="playing")pause()});
if("serviceWorker" in navigator) addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
draw();
})();