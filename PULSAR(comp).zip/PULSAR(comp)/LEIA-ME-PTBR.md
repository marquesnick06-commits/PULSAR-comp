# PULSAR(comp) — APK via GitHub Actions

Este pacote contém o jogo web offline e um fluxo de compilação Android no GitHub Actions. Ele gera um APK de depuração (debug), não um APK assinado para publicação na Play Store.

## Compilar usando somente o celular

1. Extraia o ZIP? **Não é necessário extrair no celular**; crie um repositório GitHub e envie o conteúdo desta pasta para a raiz do repositório.
2. Acesse https://github.com/new e crie um repositório vazio chamado `PULSAR-comp`.
3. No repositório, use **Add file → Upload files** e envie os arquivos e pastas desta pasta, incluindo `.github/workflows/android-apk.yml` (se o navegador ocultar arquivos que começam com ponto, crie a pasta e arquivo no GitHub pela interface web ou use a opção de upload que inclua arquivos ocultos).
4. Faça commit na branch `main`.
5. Abra a aba **Actions**. Se a execução não começar automaticamente, escolha **Build PULSAR APK** → **Run workflow**.
6. Espere a execução ficar verde. Abra a execução concluída e, em **Artifacts**, baixe `PULSAR-comp-apk`.
7. Extraia o ZIP do artifact para obter `app-debug.apk`; abra o APK e permita a instalação desta fonte se o Android solicitar.

## Observações
- A compilação requer internet no GitHub Actions, mas o APK gerado inclui os arquivos do jogo. A partida foi projetada para funcionar offline após instalação.
- O recorde é salvo localmente no armazenamento do app/WebView.
- O workflow instala o projeto Android usando Capacitor 7, Java 21 e Node.js 22.
- Este pacote não inclui um APK pré-compilado; ele inclui o código e o workflow de compilação.
- Para atualizar o jogo, altere os arquivos em `www/` e execute novamente o workflow.
